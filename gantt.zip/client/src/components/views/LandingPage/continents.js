const continent = [
    { key: 1, value: 'Africa' },
    { key: 2, value: 'Asia' },
    { key: 3, value: 'Europe' },
    { key: 4, value: 'North America' },
    { key: 5, value: 'South America' },
    { key: 6, value: 'Australia' }
]

export default continent