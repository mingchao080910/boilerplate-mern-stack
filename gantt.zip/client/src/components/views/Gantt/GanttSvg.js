import React, { useEffect, useState } from "react";
import GanttRole from "frappe-gantt-with-roles";
import Gantt from "frappe-gantt";
import { Radio } from "antd";
import GanttList from "./GanttList";
import Axios from "axios";
import moment from "moment";
function GanttSvg(props) {
  const [tasks, settasks] = useState([]);

  //view Button Change Event,切换视图
  const [View, setView] = useState("Month");
  const viewChange = (event) => {
    let view = event.target.value;
    setView(view);
    gantt.change_view_mode(view);
  };

  //组件初始化后,svg设置为gantt组件
  const [gantt, setGantt] = useState(undefined);
  useEffect(() => {
    Axios.get("/api/gantt/getList").then((res) => {
      if (!res.data.success) return alert("获取数据错误!");
      if(res.data.tableData.length===0) return;//没有数据也返回
      let data = res.data.tableData;
      settasks(data);
      //设置甘特图弹窗的样式
      const config = {
        custom_popup_html: (task) => {
  
          return `
          <div class="details-container" style="width:200px" >
            <h5  style="color: white;" >${task.name}</h5>
            <p>预计完成时间: ${moment(task.end).format("MMMM Do YY")}</p>
            <p>已完成: ${task.progress}%</p>
            <p>大类: ${task.categoryID.Category}</p>
            <p>小类: ${task.categoryID.SubCategory}</p>
            <p>备注:${task.comments ? task.comments : ""} </p>
          </div>
          `;
        },
      };
      //生成甘特图
      const ganttNew = new Gantt("#gantt", data, config);
      setGantt(ganttNew);
      ganttNew.change_view_mode(View);
      //修改甘特图的bar的颜色
      data.forEach((d) => {
        let node = document.querySelector(
          `g[data-id*="${d.name}_"] .bar-progress`
        );

        node.style.fill = d.categoryID ? d.categoryID.Color : "#8a8aff";
        node.style.opacity = 0.8;
      });
    });
  }, [View]);

  //refresh tasks
  const refreshTasks = (task) => {
    settasks(task);
  };
  return (
    <div
      style={{
        width: "85%",
        margin: "3rem auto ",
        display: "flex",
        justifyContent: "space-between",
      }}
    >
      <GanttList props={props} refresh={refreshTasks} />
      <div style={{ width: "80%" }}>
        <Radio.Group value={View} onChange={viewChange}>
          <Radio.Button value="Day">Day</Radio.Button>
          <Radio.Button value="Week">Week</Radio.Button>
          <Radio.Button value="Month">Month</Radio.Button>
        </Radio.Group>
        <svg id="gantt"></svg>
      </div>
    </div>
  );
}

export default GanttSvg;
